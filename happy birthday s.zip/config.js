var config = {
    texts: [
        " এক প্যাকেট Mixpod🚬",      
        "দুটো  বিয়ার এর বোতল 🍾", 
        "একটা Magic Moment Pide 🍾",
        "জল খরচা আমি দেবো 💦",
        "আর হ্যাঁ একটা বিড়ি নিয়ে আসবি 🚬",
        "অবশ্যই 10 এর দিলীপ বিড়ি নিবি",
        "এগুলো যদি না পাই গাঢ় মেরে দেবো😡",
        "আর শোন দাঁত কেলাবি না😅",
        "ভদ্র ছেলের মতো সন্ধেবেলা নিয়ে আসবি সব👍",
        "না হলে বাড়ি গিয়ে চুঁদে আসব🖕",
        "আজকের দিনে তোকে আশির্বাদ করলাম ✋",
        "যেন কেও তোর গাঢ় না মারতে পারে আমার জন্য বাঁচিয়ে রাখিস👌🖕",
        " Happy Birthday Motherchod 😅",
    ],
    desc: {
        turn_on: "click here🥰",
        play: "lets play music🎸",
        bannar_coming: "click me",
        balloons_flying: "ask ballons🎊 click me",
        cake_fadein: "are you ready for your cake🎂 click me",
        light_candle: "Light candle 🕯️ click me",
        wish_message: "Happy Birthday Sougata🥰🥰 click here",
        story: "A MESSAGE FOR YOU 🙂 click ",
    }
};
